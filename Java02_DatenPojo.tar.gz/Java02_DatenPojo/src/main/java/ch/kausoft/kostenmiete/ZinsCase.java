package ch.kausoft.kostenmiete;

public enum ZinsCase {
	OPTIMISTISCH, PESSIMISTISCH, REAL_IST, REDITE;
}

