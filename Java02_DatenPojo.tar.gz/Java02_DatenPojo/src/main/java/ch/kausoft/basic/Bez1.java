package ch.kausoft.basic;



public class Bez1<T,ROL> {

}
