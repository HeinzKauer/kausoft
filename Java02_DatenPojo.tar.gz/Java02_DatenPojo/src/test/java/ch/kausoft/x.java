package ch.kausoft;

import static org.junit.Assert.*;

import org.junit.Test;

public class x {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
