/**
 * @author Heinz Kauer at 04.01.2014 <br/>
 * Copyright 2007 KauSoft by KauerInformatik. All rights reserved.
 */
package ch.kausoft.attribut;

/**
 * 
 */
public class AttributCommon {
	static final String bundleName = "ch.kausoft.attribut.messages";
}
