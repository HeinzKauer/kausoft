/**
 * 
 */
package ch.kausoft.attribut.kostenmiete;

/**
 * @author Heinz
 *
 */
public interface Constant {

	static final String bundleName = "ch.kausoft.attribut.kostenmiete.messages";
}
