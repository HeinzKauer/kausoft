/**
 * Copyright 2007 KauSoft by KauerInformatik. All rights reserved.
 */

package ch.kausoft.attribut.CODE;

import ch.kausoft.attribut.ShortAttributA;

/**
 * Code
 * 
 * @author Heinz Kauer
 */
public abstract class Code extends ShortAttributA {}
