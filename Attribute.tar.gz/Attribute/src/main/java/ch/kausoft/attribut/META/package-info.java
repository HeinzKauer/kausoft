/**
 * 
 */
/**
 * @author Heinz
 *
 */
package ch.kausoft.attribut.META;