/*
 * Copyright 2007 KauSoft by KauerInformatik. All rights reserved.
 */

package ch.kausoft.attribut.CODE;

/**
 * @author Heinz
 */
public abstract class Rolle extends Code {
  
}
