/**
 * Copyright 2010 KauSoft by KauerInformatik. All rights reserved.
 *
 * @since created at 11.04.2010.22:13:54
 */
package ch.kausoft;


/**
 *
 * <BR>
 * <BR>
 * <b>Wiki:</b><br>
 * <A HREF="http://notizbuch2014.heinzkauer.ch/mediawiki/index.php?search=KauSoft"
 * >Attribut</A> Das ist ein Text im Wiki.<br>
 *
 * @author Heinz Kauer by Kauer Informatik at 11.04.2010 Projekt = ( Applikation KauSoft )
 * @since created at 11.04.2010.22:13:54
 */
public class KauSoft implements KauSoftI {}
