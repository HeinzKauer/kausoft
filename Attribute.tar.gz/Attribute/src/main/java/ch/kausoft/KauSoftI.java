/**
 * Copyright 2010 KauSoft by KauerInformatik. All rights reserved.
 * 
 * @since created at 11.04.2010.22:24:00
 */
package ch.kausoft;

/*
 * * <BR> <BR> <b>Wiki:</b><br> <A
 * HREF="http://notizbuch2014.heinzkauer.ch/mediawiki/index.php?search=KauSoftI" >KauSoftI</A>
 * Das ist ein Text im Wiki.<br>
 * @author Heinz Kauer by Kauer Informatik at 11.04.2010 Projekt = (
 * Applikation KauSoft )
 * @since created at 11.04.2010.22:24:00
 */
public interface KauSoftI {}