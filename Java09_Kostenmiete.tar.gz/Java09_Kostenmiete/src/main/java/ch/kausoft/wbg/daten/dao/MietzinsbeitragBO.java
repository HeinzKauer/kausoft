package ch.kausoft.wbg.daten.dao;

import ch.kausoft.kostenmiete.Mietzinsbeitrag;


public class MietzinsbeitragBO {

	public Mietzinsbeitrag mietzinsbeitrag;

	


}
